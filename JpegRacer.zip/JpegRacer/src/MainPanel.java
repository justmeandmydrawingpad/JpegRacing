import java.awt.Graphics;
import java.awt.Image;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class MainPanel extends JPanel{

		
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private int dogXPos;
		private final int dogYPos = 0;
		private final int dogWidth = 200;
		private final int dogHeight = 200;
		
		private int challengerXPos;
		private final int challengerYPos = 300;
		private final int challengerWidth = 200;
		private final int challengerHeight = 200;
		
		
		
		
		public MainPanel() {
			
			this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
			
		}
		
		 public void paintComponent(Graphics g){

		    super.paintComponent(g);
		    

		      
		    Image dogImage = new ImageIcon(getClass().getResource("dog.jpg")).getImage();
		    
		    g.drawImage(dogImage, dogXPos, dogYPos, dogWidth, dogHeight, this);
		    
		    
		    Image challengerImage = new ImageIcon(getClass().getResource("dog2.gif")).getImage();

		    g.drawImage(challengerImage, challengerXPos, challengerYPos, challengerWidth, challengerHeight, this);
		      
		    
		    Image flagImage = new ImageIcon(getClass().getResource("flag.jpg")).getImage();
		    
		    g.drawImage(flagImage, 800, 500, 100, 100, this);
		    
		 }
		 
			
		public void addDogXPos(int pos) {
			
			dogXPos += pos;
			
		}
		
		public void addChallengerXPos(int pos) {
			
			challengerXPos += pos;
			
		}
		
        public int getDogXPos() {
			
			return dogXPos;
			
		}
		
		public int getChallengerXPos() {
			
			return challengerXPos;
			
		}
		 
		 
		 
	}