import java.awt.BorderLayout;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionListener;
import java.util.concurrent.TimeUnit;

import javax.swing.*;
import java.util.Random;

public class JpegRacer {
	
	
	public static void main(String[] args) {
		
		
		//init frame
		JFrame frame = new JFrame("JPEG Racing");
		
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        frame.setVisible(true);

        frame.setSize(600, 500);
        
        frame.setLayout(new BorderLayout());
        
        
       //Get the default screen device
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice gs = ge.getDefaultScreenDevice();

        // Set the JFrame to be fullscreen
        gs.setFullScreenWindow(frame);
        
        
        
		//init panel
		MainPanel panel = new MainPanel();
		
        frame.getContentPane().add(panel, BorderLayout.CENTER);
        
        
        
        //init button on frame
        JButton moveButton = new JButton("->");
        
        frame.getContentPane().add(moveButton, BorderLayout.SOUTH);
        
        ActionListener buttonPress = event -> {
        	
        	panel.addDogXPos(5);
            panel.repaint();
            
            if(panel.getDogXPos() >= 600) {
            	// Remove any existing labels (to avoid multiple "win" labels)
                frame.getContentPane().removeAll();
                frame.getContentPane().add(panel, BorderLayout.CENTER); // Re-add the panel
                JLabel winLabel = new JLabel("You win!");
                frame.getContentPane().add(winLabel, BorderLayout.NORTH);
                frame.revalidate(); // Refresh layout
                frame.repaint();    // Redraw the frame
        	}
            
            
        };

        //the button press implementation wants to know when button is pressed
        moveButton.addActionListener(buttonPress);
        
        
        //move challenger
        for(int i = 0; i < 1000; i++) {
        	
        	Random random = new Random();
        	
        	panel.addChallengerXPos(random.nextInt(5));
        	if(panel.getChallengerXPos() >= 800) {
        		// Remove any existing labels (to avoid multiple "lose" labels)
                frame.getContentPane().removeAll();
                //after adding new component to jframe, must re-add all other components to make them fit
                frame.getContentPane().add(panel, BorderLayout.CENTER); // Re-add the panel
                JLabel loseLabel = new JLabel("You lose!");
                frame.getContentPane().add(loseLabel, BorderLayout.NORTH);
                frame.revalidate(); // Refresh layout
                frame.repaint();    // Redraw the frame
        	}
        	
        	panel.repaint();
        	
        	try {
        		TimeUnit.MILLISECONDS.sleep(50);
        	}
        	catch(Exception e){
        		e.printStackTrace();
        	}
        	
        	
        }

		
		
		
	}


	
}
